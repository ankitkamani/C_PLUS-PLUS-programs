/*4-WAP TO PRINT ONLY EVEN NUMBERS IN REVERSE*/
#include<iostream>
using namespace std;

int main(){

for (int i = 1; i <=10; i++)
{

if (i%2==0)
{
    cout<<"number is odd "<<i <<endl;
}

}


}