// 3-WAP TO CHECK NUMBER IS EVEN OR ODD

#include<iostream>
using namespace std;

int main(){

int n;

cout<<"enter number  = ";
cin>>n;

if (n%2)
{
    cout<<"number is odd";
}else {
    cout<<"number is even";
}



}