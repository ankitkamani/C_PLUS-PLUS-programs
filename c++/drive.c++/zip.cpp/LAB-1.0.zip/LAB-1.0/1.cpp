/*1- WAP TO SWAP TWO VALUES*/

#include<iostream>
using namespace std;

int main(){

int a,b,c;

cout<<"enter first value = ";
cin>>a;

cout<<"enter second value = ";
cin>>b;

c=a;
a=b;
b=c;
cout<<" first value = "<<a;
cout<<" second value = "<<b;

}