/*2-WAP TO FIND SIMPLE INTREST*/

#include<iostream>
using namespace std;

int main(){

float p,r,n,intrest;

cout<<"enter Principal amount  = ";
cin>>p;
cout<<"enter  Interest rate  = ";
cin>>r;
cout<<"enter year  = ";
cin>>n;

intrest=(p*r*n)/100;
cout<<" INTREST value = "<<intrest;


}