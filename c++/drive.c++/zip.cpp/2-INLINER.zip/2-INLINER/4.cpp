/*4-WAP TO USE SPECIAL ASSIGNMENT EXPRESSION*/

#include<iostream>
using namespace std;

int main(){
int a,b;
 a=b=10;

cout<<a<<endl;
cout<<b<<endl;

}