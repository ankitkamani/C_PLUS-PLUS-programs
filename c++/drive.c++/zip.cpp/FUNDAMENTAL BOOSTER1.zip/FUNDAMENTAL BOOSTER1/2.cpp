/*wap to perform addition and find the average of two numbers*/
#include<iostream>
using namespace std;

int main(){

int a,b,add,ave;

cout<<"enter first value = ";
cin>>a;

cout<<"enter second value = ";
cin>>b;

add=a+b;
cout<<"sum of 2 value is = "<<add<<endl;
ave=add/2;
cout<<"average od 2 value is = "<<ave;


}