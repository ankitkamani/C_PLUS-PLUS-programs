/*wap to use scope operators*/

#include<iostream>
using namespace std;

int a=10;
int main(){
int a=20;

cout<<"local value of a is = "<<a;
cout<<"global value of a is = "<<::a;


}
