#include<iostream>
using namespace std;

int main(){

cout<<"i am ankit kamani . now currently in RnW...";

}